#!/usr/bin/env python3
"""
Generate pixel art sprites for The Adventures of Kosh
"""
from PIL import Image, ImageDraw

# Color palette
BLACK = (30, 30, 30)
WHITE = (255, 255, 255)
YELLOW = (255, 220, 80)
GREEN = (50, 255, 100)
PINK = (255, 150, 150)
GRAY = (100, 100, 110)
TRANSPARENT = (0, 0, 0, 0)

def create_kosh_idle():
    """Create Kosh sitting idle sprite"""
    size = 64
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    # Little black cat sitting - simple design
    # Body (sitting position)
    for y in range(35, 50):
        for x in range(20, 44):
            pixels[x, y] = BLACK

    # Head
    for y in range(20, 36):
        for x in range(24, 40):
            pixels[x, y] = BLACK

    # Ears (pointy)
    # Left ear
    for y in range(16, 22):
        for x in range(24, 28):
            if y < 20 or x > 25:
                pixels[x, y] = BLACK
    # Right ear
    for y in range(16, 22):
        for x in range(36, 40):
            if y < 20 or x < 38:
                pixels[x, y] = BLACK

    # Add white/gray highlights for definition
    # Top of head highlight
    for x in range(28, 36):
        pixels[x, 20] = GRAY
        pixels[x, 21] = GRAY

    # Left side highlight
    pixels[23, 22] = GRAY
    pixels[23, 24] = GRAY
    pixels[23, 26] = GRAY
    pixels[19, 38] = GRAY
    pixels[19, 40] = GRAY

    # Right side highlight
    pixels[40, 22] = GRAY
    pixels[40, 24] = GRAY
    pixels[40, 26] = GRAY
    pixels[44, 38] = GRAY
    pixels[44, 40] = GRAY

    # White outline/glow around key areas
    # Ear tips
    pixels[25, 15] = WHITE
    pixels[38, 15] = WHITE

    # Eyes (yellow/green - make them BIGGER and brighter)
    pixels[27, 25] = YELLOW
    pixels[28, 25] = YELLOW
    pixels[29, 25] = YELLOW
    pixels[27, 26] = YELLOW
    pixels[28, 26] = YELLOW
    pixels[29, 26] = YELLOW
    pixels[27, 27] = YELLOW
    pixels[28, 27] = YELLOW
    pixels[29, 27] = YELLOW

    pixels[34, 25] = YELLOW
    pixels[35, 25] = YELLOW
    pixels[36, 25] = YELLOW
    pixels[34, 26] = YELLOW
    pixels[35, 26] = YELLOW
    pixels[36, 26] = YELLOW
    pixels[34, 27] = YELLOW
    pixels[35, 27] = YELLOW
    pixels[36, 27] = YELLOW

    # Eye pupils (green centers)
    pixels[28, 26] = GREEN
    pixels[35, 26] = GREEN

    # Nose (bigger, pinker)
    pixels[31, 30] = PINK
    pixels[32, 30] = PINK
    pixels[31, 31] = PINK
    pixels[32, 31] = PINK

    # Tail (curled around) - add highlights
    for y in range(40, 48):
        pixels[44, y] = BLACK
        pixels[45, y] = BLACK
        pixels[46, y] = GRAY  # Highlight edge
    for x in range(40, 46):
        pixels[x, 48] = BLACK
        pixels[x, 49] = BLACK
        pixels[x, 50] = GRAY  # Highlight edge

    return img

def create_kosh_meow():
    """Create Kosh meowing sprite"""
    size = 64
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    # Body
    for y in range(35, 50):
        for x in range(20, 44):
            pixels[x, y] = BLACK

    # Head (slightly tilted back)
    for y in range(22, 38):
        for x in range(24, 40):
            pixels[x, y] = BLACK

    # Ears
    for y in range(18, 24):
        for x in range(24, 28):
            if y < 22 or x > 25:
                pixels[x, y] = BLACK
    for y in range(18, 24):
        for x in range(36, 40):
            if y < 22 or x < 38:
                pixels[x, y] = BLACK

    # Highlights
    for x in range(28, 36):
        pixels[x, 22] = GRAY
    pixels[23, 24] = GRAY
    pixels[23, 26] = GRAY
    pixels[40, 24] = GRAY
    pixels[40, 26] = GRAY
    pixels[19, 38] = GRAY
    pixels[44, 38] = GRAY
    pixels[25, 17] = WHITE
    pixels[38, 17] = WHITE

    # Eyes (squinted while meowing) - bigger and brighter
    pixels[27, 28] = YELLOW
    pixels[28, 28] = YELLOW
    pixels[29, 28] = YELLOW
    pixels[34, 28] = YELLOW
    pixels[35, 28] = YELLOW
    pixels[36, 28] = YELLOW

    # Open mouth (meowing) - bigger and more visible
    pixels[30, 32] = PINK
    pixels[31, 32] = PINK
    pixels[32, 32] = PINK
    pixels[33, 32] = PINK
    pixels[30, 33] = PINK
    pixels[31, 33] = PINK
    pixels[32, 33] = PINK
    pixels[33, 33] = PINK
    # Sound waves!
    pixels[22, 30] = WHITE
    pixels[21, 31] = WHITE
    pixels[20, 32] = WHITE
    pixels[41, 30] = WHITE
    pixels[42, 31] = WHITE
    pixels[43, 32] = WHITE

    # Tail (animated up) with highlights
    for y in range(30, 45):
        pixels[44, y] = BLACK
        pixels[45, y] = BLACK
        pixels[46, y] = GRAY

    return img

def create_kosh_paw_tap():
    """Create Kosh doing paw taps sprite"""
    size = 64
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    # Body
    for y in range(35, 50):
        for x in range(20, 44):
            pixels[x, y] = BLACK

    # Head
    for y in range(20, 36):
        for x in range(24, 40):
            pixels[x, y] = BLACK

    # Ears
    for y in range(16, 22):
        for x in range(24, 28):
            if y < 20 or x > 25:
                pixels[x, y] = BLACK
    for y in range(16, 22):
        for x in range(36, 40):
            if y < 20 or x < 38:
                pixels[x, y] = BLACK

    # Highlights
    for x in range(28, 36):
        pixels[x, 20] = GRAY
        pixels[x, 21] = GRAY
    pixels[23, 22] = GRAY
    pixels[23, 24] = GRAY
    pixels[40, 22] = GRAY
    pixels[40, 24] = GRAY
    pixels[19, 38] = GRAY
    pixels[44, 38] = GRAY
    pixels[25, 15] = WHITE
    pixels[38, 15] = WHITE

    # Eyes - bigger
    pixels[27, 25] = YELLOW
    pixels[28, 25] = YELLOW
    pixels[29, 25] = YELLOW
    pixels[27, 26] = YELLOW
    pixels[28, 26] = YELLOW
    pixels[29, 26] = YELLOW
    pixels[27, 27] = YELLOW
    pixels[28, 27] = YELLOW
    pixels[29, 27] = YELLOW

    pixels[34, 25] = YELLOW
    pixels[35, 25] = YELLOW
    pixels[36, 25] = YELLOW
    pixels[34, 26] = YELLOW
    pixels[35, 26] = YELLOW
    pixels[36, 26] = YELLOW
    pixels[34, 27] = YELLOW
    pixels[35, 27] = YELLOW
    pixels[36, 27] = YELLOW

    pixels[28, 26] = GREEN
    pixels[35, 26] = GREEN

    # Nose
    pixels[31, 30] = PINK
    pixels[32, 30] = PINK
    pixels[31, 31] = PINK
    pixels[32, 31] = PINK

    # Raised paw (left side) with highlights
    for y in range(28, 36):
        pixels[18, y] = BLACK
        pixels[19, y] = BLACK
        pixels[17, y] = GRAY  # Highlight
    for x in range(16, 20):
        pixels[x, 36] = BLACK
        pixels[x, 37] = BLACK
        pixels[x, 38] = GRAY  # Highlight

    # Paw print indicator
    pixels[14, 26] = WHITE
    pixels[13, 27] = WHITE
    pixels[12, 28] = WHITE

    # Tail with highlights
    for y in range(40, 48):
        pixels[44, y] = BLACK
        pixels[45, y] = BLACK
        pixels[46, y] = GRAY

    return img

def create_kosh_zoomies():
    """Create Kosh running (zoomies) sprite"""
    size = 64
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    # Body (horizontal, running)
    for y in range(28, 38):
        for x in range(15, 40):
            pixels[x, y] = BLACK

    # Head (forward)
    for y in range(24, 34):
        for x in range(38, 48):
            pixels[x, y] = BLACK

    # Ears (flat back from speed)
    for y in range(26, 30):
        for x in range(34, 38):
            pixels[x, y] = BLACK

    # Highlights on body (showing speed and form)
    pixels[48, 26] = WHITE  # Front of head
    pixels[48, 27] = WHITE
    pixels[48, 28] = WHITE
    for x in range(20, 35):
        pixels[x, 27] = GRAY  # Top of back
    pixels[14, 30] = GRAY  # Rear
    pixels[14, 32] = GRAY

    # Eyes (determined) - bigger and glowing
    pixels[41, 27] = YELLOW
    pixels[42, 27] = YELLOW
    pixels[43, 27] = YELLOW
    pixels[41, 28] = YELLOW
    pixels[42, 28] = YELLOW
    pixels[43, 28] = YELLOW
    pixels[41, 29] = YELLOW
    pixels[42, 29] = YELLOW
    pixels[43, 29] = YELLOW
    pixels[42, 28] = GREEN  # Pupil

    # Legs (motion blur with highlights)
    # Back legs
    pixels[18, 38] = BLACK
    pixels[19, 39] = BLACK
    pixels[20, 40] = BLACK
    pixels[22, 38] = BLACK
    pixels[23, 39] = BLACK
    pixels[17, 39] = GRAY
    pixels[21, 41] = GRAY

    # Front legs
    pixels[36, 38] = BLACK
    pixels[37, 39] = BLACK
    pixels[38, 40] = BLACK
    pixels[35, 39] = GRAY

    # Tail (streaming behind) with highlights
    for y in range(26, 32):
        pixels[12, y] = BLACK
        pixels[13, y] = BLACK
        pixels[11, y] = GRAY
    for x in range(10, 15):
        pixels[x, 28] = BLACK
        pixels[x, 29] = BLACK
        pixels[x, 27] = GRAY

    # Speed lines! (more dramatic)
    for i in range(5):
        y = 18 + i * 4
        for x in range(3, 12):
            if x % 2 == 0:  # Dashed lines
                pixels[x, y] = WHITE

    # Extra speed effect
    pixels[50, 30] = WHITE
    pixels[51, 30] = WHITE
    pixels[50, 32] = WHITE
    pixels[51, 32] = WHITE

    return img

def create_kosh_sleeping():
    """Create Kosh sleeping sprite"""
    size = 64
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    # Curled up ball of cat
    for y in range(30, 45):
        for x in range(20, 44):
            if (x - 32) ** 2 + (y - 37) ** 2 < 150:
                pixels[x, y] = BLACK

    # Highlights on the curled body
    for x in range(25, 40):
        if (x - 32) ** 2 + (30 - 37) ** 2 < 150:
            pixels[x, 30] = GRAY
            pixels[x, 31] = GRAY

    # Head tucked in
    for y in range(32, 40):
        for x in range(20, 28):
            pixels[x, y] = BLACK

    # Ears (barely visible) with white tips
    pixels[22, 32] = BLACK
    pixels[23, 32] = BLACK
    pixels[26, 33] = BLACK
    pixels[27, 33] = BLACK
    pixels[22, 31] = WHITE
    pixels[26, 32] = WHITE

    # Tail wrapped around with highlights
    for x in range(28, 44):
        pixels[x, 44] = BLACK
        pixels[x, 45] = BLACK
        pixels[x, 46] = GRAY
    for y in range(38, 45):
        pixels[43, y] = BLACK
        pixels[44, y] = BLACK
        pixels[45, y] = GRAY

    # Add some subtle breathing/shape definition
    pixels[19, 35] = GRAY
    pixels[19, 37] = GRAY
    pixels[44, 35] = GRAY
    pixels[44, 37] = GRAY

    # Zzz (sleeping indicator) - bigger and more visible
    # First Z
    for x in range(46, 52):
        pixels[x, 18] = WHITE
        pixels[x, 19] = WHITE
    pixels[46, 20] = WHITE
    pixels[47, 21] = WHITE
    pixels[48, 22] = WHITE
    pixels[49, 23] = WHITE
    pixels[50, 24] = WHITE
    for x in range(46, 52):
        pixels[x, 25] = WHITE
        pixels[x, 26] = WHITE

    # Second Z (smaller, higher)
    for x in range(50, 54):
        pixels[x, 12] = WHITE
    pixels[50, 13] = WHITE
    pixels[51, 14] = WHITE
    pixels[52, 15] = WHITE
    for x in range(50, 54):
        pixels[x, 16] = WHITE

    return img

def create_dad_sleeping():
    """Create sleeping dad sprite - more human-like"""
    size = 64
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    SKIN = (255, 220, 180)
    HAIR = (80, 60, 40)
    BLANKET = (100, 150, 200)
    PILLOW = (240, 240, 250)
    PAJAMAS = (180, 200, 220)

    # Pillow (white)
    for y in range(18, 30):
        for x in range(12, 36):
            pixels[x, y] = PILLOW

    # Head (more rounded)
    for y in range(20, 34):
        for x in range(16, 32):
            if (x - 24) ** 2 + (y - 27) ** 2 < 80:
                pixels[x, y] = SKIN

    # Hair (messy on pillow)
    for y in range(20, 26):
        for x in range(16, 32):
            if (x - 24) ** 2 + (y - 23) ** 2 < 60:
                pixels[x, y] = HAIR
    # Hair strands
    pixels[17, 24] = HAIR
    pixels[18, 25] = HAIR
    pixels[30, 24] = HAIR
    pixels[29, 25] = HAIR

    # Closed eyes
    for x in range(20, 23):
        pixels[x, 28] = (40, 20, 10)
    for x in range(26, 29):
        pixels[x, 28] = (40, 20, 10)

    # Nose (small bump)
    pixels[24, 29] = (235, 200, 160)
    pixels[24, 30] = (235, 200, 160)

    # Mouth (peaceful sleep)
    pixels[23, 32] = (200, 150, 140)
    pixels[24, 32] = (200, 150, 140)

    # Body under blanket
    for y in range(32, 50):
        for x in range(10, 54):
            if y > 32 + abs(x - 32) * 0.3:
                pixels[x, y] = BLANKET

    # Shoulder/pajama visible
    for y in range(30, 36):
        for x in range(14, 26):
            pixels[x, y] = PAJAMAS

    # Zzz (bigger and clearer)
    # First Z
    for x in range(38, 44):
        pixels[x, 12] = WHITE
        pixels[x, 13] = WHITE
    pixels[38, 14] = WHITE
    pixels[39, 15] = WHITE
    pixels[40, 16] = WHITE
    pixels[41, 17] = WHITE
    for x in range(38, 44):
        pixels[x, 18] = WHITE
        pixels[x, 19] = WHITE

    # Second Z (smaller)
    for x in range(42, 46):
        pixels[x, 8] = WHITE
    pixels[42, 9] = WHITE
    pixels[43, 10] = WHITE
    for x in range(42, 46):
        pixels[x, 11] = WHITE

    return img

def create_dad_awake():
    """Create awake dad sprite - more human-like"""
    size = 64
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    SKIN = (255, 220, 180)
    HAIR = (80, 60, 40)
    BLANKET = (100, 150, 200)
    TSHIRT = (150, 100, 100)
    EYES = (60, 40, 30)

    # Blanket (waist down)
    for y in range(36, 50):
        for x in range(18, 46):
            if y > 36 + abs(x - 32) * 0.2:
                pixels[x, y] = BLANKET

    # T-shirt/pajama top (sitting up)
    for y in range(26, 38):
        for x in range(22, 42):
            if (x - 32) ** 2 + (y - 32) ** 2 < 120:
                pixels[x, y] = TSHIRT

    # Shoulders more defined
    for y in range(26, 30):
        for x in range(22, 28):
            pixels[x, y] = TSHIRT
        for x in range(36, 42):
            pixels[x, y] = TSHIRT

    # Neck
    for y in range(22, 26):
        for x in range(29, 35):
            pixels[x, y] = SKIN

    # Head (more rounded and proportional)
    for y in range(12, 26):
        for x in range(26, 38):
            if (x - 32) ** 2 + (y - 19) ** 2 < 90:
                pixels[x, y] = SKIN

    # Hair (messy bedhead)
    for y in range(12, 18):
        for x in range(26, 38):
            if (x - 32) ** 2 + (y - 15) ** 2 < 85:
                pixels[x, y] = HAIR
    # Spiky hair strands
    pixels[28, 11] = HAIR
    pixels[29, 10] = HAIR
    pixels[32, 10] = HAIR
    pixels[35, 11] = HAIR
    pixels[36, 11] = HAIR

    # Eyes (tired but open)
    # Left eye
    for x in range(28, 31):
        pixels[x, 19] = EYES
    pixels[29, 20] = BLACK

    # Right eye
    for x in range(33, 36):
        pixels[x, 19] = EYES
    pixels[34, 20] = BLACK

    # Eyebrows (tired/grumpy)
    pixels[28, 17] = HAIR
    pixels[29, 17] = HAIR
    pixels[30, 17] = HAIR
    pixels[33, 17] = HAIR
    pixels[34, 17] = HAIR
    pixels[35, 17] = HAIR

    # Nose
    pixels[31, 21] = (235, 200, 160)
    pixels[32, 21] = (235, 200, 160)
    pixels[31, 22] = (235, 200, 160)
    pixels[32, 22] = (235, 200, 160)

    # Yawning mouth (open)
    for x in range(30, 34):
        pixels[x, 24] = PINK
        pixels[x, 25] = PINK
    pixels[31, 26] = PINK
    pixels[32, 26] = PINK

    # Arms (one visible)
    for y in range(30, 38):
        for x in range(20, 24):
            pixels[x, y] = SKIN
    # Hand
    for x in range(18, 22):
        pixels[x, 38] = SKIN
        pixels[x, 39] = SKIN

    return img

def create_window_closed():
    """Create closed window sprite"""
    size = 128
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    # Window frame (brown)
    BROWN = (120, 80, 40)
    for y in range(10, 118):
        for x in range(10, 118):
            if x < 15 or x > 112 or y < 15 or y > 112:
                pixels[x, y] = BROWN

    # Window panes (dark - closed)
    DARK_BLUE = (40, 60, 80)
    for y in range(15, 60):
        for x in range(15, 60):
            pixels[x, y] = DARK_BLUE
    for y in range(15, 60):
        for x in range(68, 113):
            pixels[x, y] = DARK_BLUE
    for y in range(68, 113):
        for x in range(15, 60):
            pixels[x, y] = DARK_BLUE
    for y in range(68, 113):
        for x in range(68, 113):
            pixels[x, y] = DARK_BLUE

    # Window cross frame
    for y in range(10, 118):
        for x in range(61, 66):
            pixels[x, y] = BROWN
    for y in range(61, 66):
        for x in range(10, 118):
            pixels[x, y] = BROWN

    return img

def create_window_open():
    """Create open window sprite"""
    size = 128
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    # Window frame
    BROWN = (120, 80, 40)
    for y in range(10, 118):
        for x in range(10, 118):
            if x < 15 or x > 112 or y < 15 or y > 112:
                pixels[x, y] = BROWN

    # Window panes (bright - open!)
    SKY_BLUE = (135, 206, 250)
    for y in range(15, 60):
        for x in range(15, 60):
            pixels[x, y] = SKY_BLUE
    for y in range(15, 60):
        for x in range(68, 113):
            pixels[x, y] = SKY_BLUE
    for y in range(68, 113):
        for x in range(15, 60):
            pixels[x, y] = SKY_BLUE
    for y in range(68, 113):
        for x in range(68, 113):
            pixels[x, y] = SKY_BLUE

    # Window cross frame
    for y in range(10, 118):
        for x in range(61, 66):
            pixels[x, y] = BROWN
    for y in range(61, 66):
        for x in range(10, 118):
            pixels[x, y] = BROWN

    # Little birds visible
    # Bird 1
    pixels[30, 35] = BLACK
    pixels[31, 35] = BLACK
    pixels[28, 36] = BLACK
    pixels[33, 36] = BLACK

    # Bird 2
    pixels[85, 45] = BLACK
    pixels[86, 45] = BLACK
    pixels[83, 46] = BLACK
    pixels[88, 46] = BLACK

    return img

def create_easter_egg():
    """Create colorful easter egg sprite"""
    size = 64
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    EGG_BASE = (240, 220, 255)  # Light lavender
    STRIPE_PINK = (255, 150, 200)
    STRIPE_BLUE = (150, 200, 255)
    STRIPE_YELLOW = (255, 240, 150)
    HIGHLIGHT = (255, 255, 255)

    # Egg shape (oval)
    for y in range(18, 50):
        for x in range(20, 44):
            # Oval equation
            if (x - 32) ** 2 / 110 + (y - 34) ** 2 / 240 < 1:
                pixels[x, y] = EGG_BASE

    # Decorative stripes (zigzag pattern)
    for x in range(22, 42):
        # Top stripe
        y = 24 + (x % 4)
        pixels[x, y] = STRIPE_PINK
        pixels[x, y + 1] = STRIPE_PINK

        # Middle stripe
        y = 32 + ((x + 2) % 4)
        pixels[x, y] = STRIPE_BLUE
        pixels[x, y + 1] = STRIPE_BLUE

        # Bottom stripe
        y = 40 + (x % 4)
        pixels[x, y] = STRIPE_YELLOW
        pixels[x, y + 1] = STRIPE_YELLOW

    # Polka dots
    dot_positions = [(26, 28), (36, 29), (28, 36), (35, 37), (30, 44)]
    for dx, dy in dot_positions:
        pixels[dx, dy] = STRIPE_PINK
        pixels[dx + 1, dy] = STRIPE_PINK
        pixels[dx, dy + 1] = STRIPE_PINK
        pixels[dx + 1, dy + 1] = STRIPE_PINK

    # Highlight (shiny egg)
    pixels[27, 22] = HIGHLIGHT
    pixels[28, 22] = HIGHLIGHT
    pixels[29, 22] = HIGHLIGHT
    pixels[27, 23] = HIGHLIGHT
    pixels[28, 23] = HIGHLIGHT

    # Sparkle effect
    pixels[38, 20] = HIGHLIGHT
    pixels[39, 19] = HIGHLIGHT
    pixels[40, 20] = HIGHLIGHT
    pixels[39, 21] = HIGHLIGHT

    return img

def create_raccoon_toy():
    """Create cute raccoon plushie sprite"""
    size = 64
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    GRAY = (140, 140, 150)
    DARK_GRAY = (80, 80, 90)
    NOSE = (60, 50, 50)
    EYE_WHITE = (255, 255, 255)
    EYE_BLACK = (30, 30, 30)

    # Body (round plushie shape)
    for y in range(28, 48):
        for x in range(20, 44):
            if (x - 32) ** 2 / 140 + (y - 38) ** 2 / 90 < 1:
                pixels[x, y] = GRAY

    # Head (attached to body)
    for y in range(18, 34):
        for x in range(24, 40):
            if (x - 32) ** 2 / 60 + (y - 26) ** 2 / 60 < 1:
                pixels[x, y] = GRAY

    # Ears (round, small)
    # Left ear
    for y in range(16, 22):
        for x in range(24, 28):
            if (x - 26) ** 2 + (y - 19) ** 2 < 9:
                pixels[x, y] = GRAY
    # Right ear
    for y in range(16, 22):
        for x in range(36, 40):
            if (x - 38) ** 2 + (y - 19) ** 2 < 9:
                pixels[x, y] = GRAY

    # Raccoon mask (dark patches around eyes)
    # Left eye patch
    for y in range(24, 29):
        for x in range(26, 30):
            pixels[x, y] = DARK_GRAY
    # Right eye patch
    for y in range(24, 29):
        for x in range(34, 38):
            pixels[x, y] = DARK_GRAY

    # Eyes (big cute eyes)
    # Left eye
    pixels[27, 26] = EYE_WHITE
    pixels[28, 26] = EYE_WHITE
    pixels[27, 27] = EYE_WHITE
    pixels[28, 27] = EYE_WHITE
    pixels[28, 27] = EYE_BLACK  # pupil

    # Right eye
    pixels[35, 26] = EYE_WHITE
    pixels[36, 26] = EYE_WHITE
    pixels[35, 27] = EYE_WHITE
    pixels[36, 27] = EYE_WHITE
    pixels[35, 27] = EYE_BLACK  # pupil

    # Nose (small triangle)
    pixels[31, 30] = NOSE
    pixels[32, 30] = NOSE
    pixels[31, 31] = NOSE
    pixels[32, 31] = NOSE
    pixels[32, 32] = NOSE

    # Tail stripes (curled around back)
    tail_x = 42
    for y in range(32, 44, 3):
        # Alternating stripes
        pixels[tail_x, y] = GRAY
        pixels[tail_x + 1, y] = GRAY
        pixels[tail_x, y + 1] = DARK_GRAY
        pixels[tail_x + 1, y + 1] = DARK_GRAY

    # Paws (small dark ovals)
    # Left paw
    for x in range(24, 28):
        pixels[x, 46] = DARK_GRAY
        pixels[x, 47] = DARK_GRAY
    # Right paw
    for x in range(36, 40):
        pixels[x, 46] = DARK_GRAY
        pixels[x, 47] = DARK_GRAY

    return img

def create_wardrobe():
    """Create wardrobe/closet sprite"""
    size = 128
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    WOOD_DARK = (80, 50, 30)
    WOOD_LIGHT = (110, 70, 40)
    WOOD_MED = (95, 60, 35)
    HANDLE = (180, 160, 100)

    # Wardrobe frame (rectangular)
    for y in range(10, 118):
        for x in range(10, 118):
            if x < 15 or x > 112 or y < 15 or y > 112:
                pixels[x, y] = WOOD_DARK

    # Left door
    for y in range(15, 113):
        for x in range(15, 62):
            pixels[x, y] = WOOD_MED

    # Right door
    for y in range(15, 113):
        for x in range(66, 113):
            pixels[x, y] = WOOD_MED

    # Door panels (decorative)
    # Left door panel
    for y in range(25, 50):
        for x in range(20, 57):
            if x < 22 or x > 55 or y < 27 or y > 48:
                pixels[x, y] = WOOD_LIGHT

    for y in range(60, 103):
        for x in range(20, 57):
            if x < 22 or x > 55 or y < 62 or y > 101:
                pixels[x, y] = WOOD_LIGHT

    # Right door panel
    for y in range(25, 50):
        for x in range(71, 108):
            if x < 73 or x > 106 or y < 27 or y > 48:
                pixels[x, y] = WOOD_LIGHT

    for y in range(60, 103):
        for x in range(71, 108):
            if x < 73 or x > 106 or y < 62 or y > 101:
                pixels[x, y] = WOOD_LIGHT

    # Door handles
    # Left handle
    for y in range(62, 68):
        for x in range(54, 60):
            pixels[x, y] = HANDLE

    # Right handle
    for y in range(62, 68):
        for x in range(68, 74):
            pixels[x, y] = HANDLE

    # Center line (where doors meet)
    for y in range(15, 113):
        pixels[63, y] = WOOD_DARK
        pixels[64, y] = WOOD_DARK

    return img

def create_food_bowl_empty():
    """Create empty food bowl sprite"""
    size = 64
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    BOWL_OUTER = (180, 160, 140)
    BOWL_INNER = (200, 180, 160)
    BOWL_RIM = (160, 140, 120)
    SHADOW = (80, 70, 60)

    # Shadow under bowl
    for x in range(10, 54):
        pixels[x, 48] = SHADOW
        pixels[x, 49] = SHADOW

    # Bowl base (oval/circular)
    for y in range(38, 48):
        for x in range(16, 48):
            if (x - 32) ** 2 / 200 + (y - 42) ** 2 / 50 < 1:
                pixels[x, y] = BOWL_OUTER

    # Bowl rim (top edge)
    for x in range(14, 50):
        if (x - 32) ** 2 < 320:
            pixels[x, 36] = BOWL_RIM
            pixels[x, 37] = BOWL_RIM

    # Bowl inner (lighter color showing emptiness)
    for y in range(38, 46):
        for x in range(18, 46):
            if (x - 32) ** 2 / 180 + (y - 42) ** 2 / 40 < 1:
                pixels[x, y] = BOWL_INNER

    # Highlight on rim (shiny ceramic)
    for x in range(26, 38):
        pixels[x, 36] = WHITE

    return img

def create_food_bowl_full():
    """Create full food bowl sprite"""
    size = 64
    img = Image.new('RGBA', (size, size), TRANSPARENT)
    pixels = img.load()

    BOWL_OUTER = (180, 160, 140)
    BOWL_RIM = (160, 140, 120)
    SHADOW = (80, 70, 60)
    FOOD_BROWN = (110, 70, 40)
    FOOD_LIGHT = (130, 90, 60)

    # Shadow under bowl
    for x in range(10, 54):
        pixels[x, 48] = SHADOW
        pixels[x, 49] = SHADOW

    # Bowl base
    for y in range(38, 48):
        for x in range(16, 48):
            if (x - 32) ** 2 / 200 + (y - 42) ** 2 / 50 < 1:
                pixels[x, y] = BOWL_OUTER

    # Bowl rim
    for x in range(14, 50):
        if (x - 32) ** 2 < 320:
            pixels[x, 36] = BOWL_RIM
            pixels[x, 37] = BOWL_RIM

    # Food in bowl (kibble pieces)
    # Main food mass
    for y in range(38, 45):
        for x in range(20, 44):
            if (x - 32) ** 2 / 160 + (y - 41) ** 2 / 30 < 1:
                # Alternate colors for texture
                if (x + y) % 3 == 0:
                    pixels[x, y] = FOOD_BROWN
                else:
                    pixels[x, y] = FOOD_LIGHT

    # Individual kibble pieces on top
    kibble_positions = [
        (24, 39), (28, 38), (32, 38), (36, 39), (40, 39),
        (26, 41), (30, 40), (34, 40), (38, 41)
    ]
    for kx, ky in kibble_positions:
        pixels[kx, ky] = FOOD_BROWN
        pixels[kx + 1, ky] = FOOD_BROWN
        pixels[kx, ky + 1] = FOOD_LIGHT

    # Highlight on rim
    for x in range(26, 38):
        pixels[x, 36] = WHITE

    return img

def create_bedroom_background():
    """Create bedroom background scene"""
    width, height = 800, 600
    img = Image.new('RGB', (width, height))
    pixels = img.load()

    # Lighter purple-blue gradient for walls (top to middle)
    for y in range(0, 400):
        for x in range(width):
            # Gradient from medium purple to lighter
            r = 60 + int((y / 400) * 30)
            g = 50 + int((y / 400) * 30)
            b = 80 + int((y / 400) * 40)
            pixels[x, y] = (r, g, b)

    # Floor (wooden planks) - lighter so Kosh is visible!
    WOOD_DARK = (110, 85, 60)
    WOOD_LIGHT = (130, 100, 70)
    for y in range(400, height):
        for x in range(width):
            # Horizontal planks
            plank_num = y // 30
            if plank_num % 2 == 0:
                color = WOOD_DARK
            else:
                color = WOOD_LIGHT
            # Add some variation
            variation = (x % 10) - 5
            pixels[x, y] = (
                max(0, min(255, color[0] + variation)),
                max(0, min(255, color[1] + variation)),
                max(0, min(255, color[2] + variation))
            )

    # Plank lines
    for y in range(400, height, 30):
        for x in range(width):
            pixels[x, y] = (50, 35, 20)

    # Add some stars in window areas (if it's night)
    star_positions = [(150, 120), (180, 90), (220, 110), (600, 95), (630, 135), (580, 115)]
    for sx, sy in star_positions:
        # Small white pixels for stars
        pixels[sx, sy] = WHITE
        pixels[sx + 1, sy] = WHITE
        pixels[sx, sy + 1] = WHITE
        pixels[sx - 1, sy] = WHITE
        pixels[sx, sy - 1] = WHITE

    return img

def main():
    print("Generating pixel art sprites for Kosh...")

    sprites = {
        'kosh_idle.png': create_kosh_idle(),
        'kosh_meow.png': create_kosh_meow(),
        'kosh_paw_tap.png': create_kosh_paw_tap(),
        'kosh_zoomies.png': create_kosh_zoomies(),
        'kosh_sleeping.png': create_kosh_sleeping(),
        'dad_sleeping.png': create_dad_sleeping(),
        'dad_awake.png': create_dad_awake(),
        'window_closed.png': create_window_closed(),
        'window_open.png': create_window_open(),
        'food_bowl_empty.png': create_food_bowl_empty(),
        'food_bowl_full.png': create_food_bowl_full(),
        'easter_egg.png': create_easter_egg(),
        'raccoon_toy.png': create_raccoon_toy(),
        'wardrobe.png': create_wardrobe(),
    }

    backgrounds = {
        'bedroom_bg.png': create_bedroom_background(),
    }

    for filename, sprite in sprites.items():
        sprite.save(f'assets/sprites/{filename}')
        print(f"  Created {filename}")

    for filename, bg in backgrounds.items():
        bg.save(f'assets/sprites/{filename}')
        print(f"  Created {filename}")

    print("\nAll sprites and backgrounds generated successfully!")

if __name__ == '__main__':
    main()
